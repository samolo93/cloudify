# Cloudify Manager blueprints #

Contains customized Cloudify Manager blueprints for bootstrapping the Cloudify Manager

 - Openstack infrastructure hosted by OVH
    - ovh-openstack-manager-blueprint.yaml
    - ovh-openstack-manager-blueprint-inputs.yaml

## Usage

1. Copy the manager blueprint and corresponding inputs file into the cloudify-manager-blueprints folder in your Cloudfy installation directory (eg. /opt/cfy/cloudify-manager-blueprints on Linux)
2. Edit the inputs file according to the environment where you want to bootstrap the Cloudify Manager
3. Bootstrap the Cloudify Manager

	`cfy bootstrap --install-plugins -p /path/to/manager/blueprint/file -i /path/to/inputs/yaml/file`
 